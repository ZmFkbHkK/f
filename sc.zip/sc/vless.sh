#!/bin/bash

function style_all() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}             VLESS ACCOUNT               ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Username      : ${user}"
echo -e " User Quota    : ${Quota} GB"
echo -e " Limit IP      : ${iplimit} Device"
echo -e " Host/IP       : ${domain}"
echo -e " ISP           : ${ISP}"
echo -e " Country       : ${CITY}"
echo -e " id            : ${uuid}"
echo -e " Port TLS      : $tls"
echo -e " Port none TLS : $ntls"
echo -e " Encryption    : none"
echo -e " Network       : ws - grpc"
echo -e " Path          : /vless"
echo -e " ServiceName   : vless-grpc"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link TLS      : ${vlesslink1}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link none TLS : ${vlesslink2}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link GRPC     : ${vlesslink3}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Format OpenClash : https://${domain}:89/vless-$user.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e ""
}

function style_ws() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}             VLESS ACCOUNT               ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Username      : ${user}"
echo -e " User Quota    : ${Quota} GB"
echo -e " Limit IP      : ${iplimit} Device"
echo -e " Host/IP       : ${domain}"
echo -e " ISP           : ${ISP}"
echo -e " Country       : ${CITY}"
echo -e " id            : ${uuid}"
echo -e " Port TLS      : $tls"
echo -e " Port none TLS : $ntls"
echo -e " Encryption    : none"
echo -e " Network       : ws"
echo -e " Path          : /vless"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link TLS      : ${vlesslink1}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link none TLS : ${vlesslink2}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Format OpenClash : https://${domain}:89/vless-$user.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e ""
}

function style_grpc() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}             VLESS ACCOUNT               ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Username      : ${user}"
echo -e " User Quota    : ${Quota} GB"
echo -e " Limit IP      : ${iplimit} Device"
echo -e " Host/IP       : ${domain}"
echo -e " ISP           : ${ISP}"
echo -e " Country       : ${CITY}"
echo -e " id            : ${uuid}"
echo -e " Port TLS      : $tls"
echo -e " Port none TLS : $ntls"
echo -e " Encryption    : none"
echo -e " Network       : grpc"
echo -e " ServiceName   : vless-grpc"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link GRPC     : ${vlesslink3}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Format OpenClash : https://${domain}:89/vless-$user.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e ""
}

function format_all() {
cat >/var/www/html/vless-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
        Format Vless WS [TLS]
-----------------------------------------

- name: Vless-$user-WS TLS
  server: ${domain}
  port: $tls
  type: vless
  uuid: ${uuid}
  cipher: auto
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: ws
  ws-opts:
    path: /vless
    headers:
      Host: ${domain}

-----------------------------------------
        Format Vless WS TLS
-----------------------------------------

- name: Vless-$user-WS (CDN) Non TLS
  server: ${domain}
  port: $ntls
  type: vless
  uuid: ${uuid}
  cipher: auto
  tls: false
  skip-cert-verify: false
  servername: none
  network: ws
  ws-opts:
    path: /vless
    headers:
      Host: ${domain}
  udp: true

-----------------------------------------
        Format Vless gRPC
-----------------------------------------

- name: Vless-$user-gRPC (SNI)
  server: ${domain}
  port: $tls
  type: vless
  uuid: ${uuid}
  cipher: auto
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: grpc
  grpc-opts:
  grpc-mode: gun
    grpc-service-name: vless-grpc

-----------------------------------------
    Link Vless Account
-----------------------------------------
Link WS TLS   : 
${vlesslink1}
-----------------------------------------
Link none TLS : 
${vlesslink2}
-----------------------------------------
Link GRPC     : 
${vlesslink3}
-----------------------------------------
END
}

function format_ws() {
cat >/var/www/html/vless-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
        Format Vless WS [TLS]
-----------------------------------------

- name: Vless-$user-WS TLS
  server: ${domain}
  port: $tls
  type: vless
  uuid: ${uuid}
  cipher: auto
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: ws
  ws-opts:
    path: /vless
    headers:
      Host: ${domain}

-----------------------------------------
        Format Vless WS TLS
-----------------------------------------

- name: Vless-$user-WS (CDN) Non TLS
  server: ${domain}
  port: $ntls
  type: vless
  uuid: ${uuid}
  cipher: auto
  tls: false
  skip-cert-verify: false
  servername: none
  network: ws
  ws-opts:
    path: /vless
    headers:
      Host: ${domain}
  udp: true

-----------------------------------------
    Link Vless Account
-----------------------------------------
Link WS TLS   : 
${vlesslink1}
-----------------------------------------
Link none TLS : 
${vlesslink2}
-----------------------------------------
END
}

function format_grpc() {
cat >/var/www/html/vless-$user.txt <<-END
-----------------------------------------
        XD PROJECT TUNNEL
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
        Format Vless gRPC
-----------------------------------------

- name: Vless-$user-gRPC (SNI)
  server: ${domain}
  port: $tls
  type: vless
  uuid: ${uuid}
  cipher: auto
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: grpc
  grpc-opts:
  grpc-mode: gun
    grpc-service-name: vless-grpc

-----------------------------------------
    Link Vless Account
-----------------------------------------
Link GRPC     : 
${vlesslink3}
-----------------------------------------
END
}

 if [[ ${1} == "all" ]]; then
   style_all
 fi
 if [[ ${1} == "ws" ]]; then
   style_ws
 fi
 if [[ ${1} == "grpc" ]]; then
   style_grpc
 fi

 if [[ ${1} == "format_all" ]]; then
   format_all
 fi
 if [[ ${1} == "format_ws" ]]; then
   format_ws
 fi
 if [[ ${1} == "format_grpc" ]]; then
   format_grpc
 fi