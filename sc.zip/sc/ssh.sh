#!/bin/bash

function log_all() {
clear
echo -e "
${blue}————————————————————————————————————————${NC}
${ungu}           SSH OVPN ACCOUNT             ${NC}
${blue}————————————————————————————————————————${NC}
 Username     : $user
 Password     : $Pass
 Limit IP     : ${iplimit} Device
${blue}————————————————————————————————————————${NC}
 SSH Port 80 : ${domain}:80@${user}:${Pass}
 UDP Custom  : ${domain}:54-65535@${user}:${Pass}
${blue}————————————————————————————————————————${NC}
 SSH SlowDNS  : $slowdns
 Host Slowdns : $hostslow
 Pubkey       : $serverpub
${blue}————————————————————————————————————————${NC}
 ISP          : $ISP
 Country      : $CITY
 Host/IP      : $domain
 OpenSSH      : $openssh
 SSH UDP      : $udp
 Dropbear     : $dropbear
 OpenVPN      : $openvpn
 Proxy Squid  : $squid
 BadVPN       : $badvpn
 WSS SSL/TLS  : $tls
 WSS none TLS : $ntls
${blue}————————————————————————————————————————${NC}
 OVPN Download    : https://$domain:89/
${blue}————————————————————————————————————————${NC}
 Save Link Account: https://$domain:89/ssh-$user.txt
${blue}————————————————————————————————————————${NC}
 Payload NTLS:
 GET / HTTP/1.1[crlf]host: ${domain}[crlf]Upgrade: Websocket[crlf][crlf]
${blue}————————————————————————————————————————${NC}
 Payload  TLS:
 GET http://bug.con/ HTTP/1.1[crlf]host: ${domain}[crlf]Upgrade: Websocket[crlf][crlf]
${blue}————————————————————————————————————————${NC}
   Created On : $hariini
   Expired On : $exp
${blue}————————————————————————————————————————${NC}"
echo -e ""
}

function format_all() {
cat >/var/www/html/ssh-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
        Format SSH OVPN
-----------------------------------------
Username       : $user
Password       : $Pass
Limit IP       : $iplimit Device
-----------------------------------------
SSH Port 80    : ${domain}:80@${user}:${Pass}
SSH UDP Custom : ${domain}:54-65535@${user}:${Pass}
-----------------------------------------
SSH SlowDNS    : $slowdns
Host Slowdns   : $hostslow
Pubkey         : $serverpub
-----------------------------------------
ISP          : $ISP
Country      : $CITY
Host/IP      : $domain
OpenSSH      : $openssh
SSH UDP      : $udp
Dropbear     : $dropbear
OpenVPN      : $openvpn
Proxy Squid  : $squid
BadVPN       : $badvpn
WSS SSL/TLS  : $tls
WSS none TLS : $ntls
-----------------------------------------
GET / HTTP/1.1[crlf]Host: $domain[crlf]Upgrade: websocket[crlf][crlf]
-----------------------------------------
Payload Websocket TLS: 
GET wss://bug.com/ HTTP/1.1[crlf]Host: $domain[crlf]Upgrade: websocket[crlf][crlf]
-----------------------------------------
OVPN Download : https://$domain:89/
-----------------------------------------

END
}
 if [[ ${1} == "all" ]]; then
   log_all
 fi

 if [[ ${1} == "format_all" ]]; then
   format_all
 fi