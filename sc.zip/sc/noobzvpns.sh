#!/bin/bash

function log_all() {
clear
echo -e "
${blue}————————————————————————————————————————${NC}
${ungu}           NoobzVPNS Account            ${NC}
${blue}————————————————————————————————————————${NC}
Username  : $user
Password  : $Pass
${blue}————————————————————————————————————————${NC}
ISP       : $ISP
Country   : $CITY
Host/Ip   : $domain
${blue}————————————————————————————————————————${NC}
Port TCP_STD : $ntls
Port TCP_SSL : $tls
${blue}————————————————————————————————————————${NC}
Save Link Account: https://$domain:89/noobz-$user.txt
${blue}————————————————————————————————————————${NC}
Created On : $hariini
Expired On : $exp
${blue}————————————————————————————————————————${NC}"
echo -e ""
}

function format_all() {
cat >/var/www/html/noobz-$user.txt <<-END
───────────────────
Format Noobzvpns Account
───────────────────
Username          : $user
Password          : $Pass
───────────────────
ISP       : $ISP
Country   : $CITY
Host/Ip   : $domain
───────────────────
Port TCP_STD : $ntls
Port TCP_SSL : $tls
───────────────────
END
}

 if [[ ${1} == "all" ]]; then
   log_all
 fi

 if [[ ${1} == "format_all" ]]; then
   format_all
 fi