#!/bin/bash

function style_all() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}          SHADOWSOCKS ACCOUNT            ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Username    : ${user}"
echo -e "Domain      : ${domain}"
echo -e "Key         : ${uuid}"
echo -e "Port TLS    : $tls"
echo -e "Port NTLS   : $ntls"
echo -e "Cipers      : aes-128-gcm"
echo -e "Network     : ws - grpc"
echo -e "Path        : /shadowsocks"
echo -e "ServiceName : shadowsocks-grpc"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Link TLS : ${sstls}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Link None TLS : ${ssntls}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Link GRPC : ${ssgrpc}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Format Shadowsocks : https://${domain}:89/ss-${user}.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
}

function style_ws() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}          SHADOWSOCKS ACCOUNT            ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Username    : ${user}"
echo -e "Domain      : ${domain}"
echo -e "Key         : ${uuid}"
echo -e "Port TLS    : $tls"
echo -e "Port NTLS   : $ntls"
echo -e "Cipers      : aes-128-gcm"
echo -e "Network     : ws"
echo -e "Path        : /shadowsocks"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Link TLS : ${sslinkws}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Link None TLS : ${nonsslinkws}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Format Shadowsocks : https://${domain}:89/ss-${user}.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
}

function style_grpc() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}          SHADOWSOCKS ACCOUNT            ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Username    : ${user}"
echo -e "Domain      : ${domain}"
echo -e "Key         : ${uuid}"
echo -e "Port TLS    : $tls"
echo -e "Port NTLS   : $ntls"
echo -e "Cipers      : aes-128-gcm"
echo -e "Network     : grpc"
echo -e "ServiceName : shadowsocks-grpc"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Link GRPC : ${sslinkgrpc}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "Format Shadowsocks : https://${domain}:89/ss-${user}.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
}


function format_all() {
cat > /var/www/html/ss-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
      Format Shadowsocks WS
-----------------------------------------
{
 "dns": {
    "servers": [
      "8.8.8.8",
      "8.8.4.4"
    ]
  },
 "inbounds": [
   {
      "port": 10808,
      "protocol": "socks",
      "settings": {
        "auth": "noauth",
        "udp": true,
        "userLevel": 8
      },
      "sniffing": {
        "destOverride": [
          "http",
          "tls"
        ],
        "enabled": true
      },
      "tag": "socks"
    },
    {
      "port": 10809,
      "protocol": "http",
      "settings": {
        "userLevel": 8
      },
      "tag": "http"
    }
  ],
  "log": {
    "loglevel": "none"
  },
  "outbounds": [
    {
      "mux": {
        "enabled": true
      },
      "protocol": "shadowsocks",
      "settings": {
        "servers": [
          {
            "address": "$domain",
            "level": 8,
            "method": "$cipher",
            "password": "$uuid",
            "port": $tls
          }
        ]
      },
      "streamSettings": {
        "network": "ws",
        "security": "tls",
        "tlsSettings": {
          "allowInsecure": true,
          "serverName": "isi_bug_disini"
        },
        "wsSettings": {
          "headers": {
            "Host": "$domain"
          },
          "path": "/shadowsocks"
        }
      },
      "tag": "proxy"
    },
    {
      "protocol": "freedom",
      "settings": {},
      "tag": "direct"
    },
    {
      "protocol": "blackhole",
      "settings": {
        "response": {
          "type": "http"
        }
      },
      "tag": "block"
    }
  ],
  "policy": {
    "levels": {
      "8": {
        "connIdle": 300,
        "downlinkOnly": 1,
        "handshake": 4,
        "uplinkOnly": 1
      }
    },
    "system": {
      "statsOutboundUplink": true,
      "statsOutboundDownlink": true
    }
  },
  "routing": {
    "domainStrategy": "Asls",
"rules": []
  },
  "stats": {}
}

-----------------------------------------
      Format Shadowsocks gRPC
-----------------------------------------

{
    "dns": {
    "servers": [
      "8.8.8.8",
      "8.8.4.4"
    ]
  },
 "inbounds": [
   {
      "port": 10808,
      "protocol": "socks",
      "settings": {
        "auth": "noauth",
        "udp": true,
        "userLevel": 8
      },
      "sniffing": {
        "destOverride": [
          "http",
          "tls"
        ],
        "enabled": true
      },
      "tag": "socks"
    },
    {
      "port": 10809,
      "protocol": "http",
      "settings": {
        "userLevel": 8
      },
      "tag": "http"
    }
  ],
  "log": {
    "loglevel": "none"
  },
  "outbounds": [
    {
      "mux": {
        "enabled": true
      },
      "protocol": "shadowsocks",
      "settings": {
        "servers": [
          {
            "address": "$domain",
            "level": 8,
            "method": "$cipher",
            "password": "$uuid",
            "port": $tls
          }
        ]
      },
      "streamSettings": {
        "grpcSettings": {
          "multiMode": true,
          "serviceName": "shadowsocks"
        },
        "network": "grpc",
        "security": "tls",
        "tlsSettings": {
          "allowInsecure": true,
          "serverName": "isi_bug_disini"
        }
      },
      "tag": "proxy"
    },
    {
      "protocol": "freedom",
      "settings": {},
      "tag": "direct"
    },
    {
      "protocol": "blackhole",
      "settings": {
        "response": {
          "type": "http"
        }
      },
      "tag": "block"
    }
  ],
  "policy": {
    "levels": {
      "8": {
        "connIdle": 300,
        "downlinkOnly": 1,
        "handshake": 4,
        "uplinkOnly": 1
      }
    },
    "system": {
      "statsOutboundUplink": true,
      "statsOutboundDownlink": true
    }
  },
  "routing": {
    "domainStrategy": "Asls",
"rules": []
  },
  "stats": {}
}
END
}

function format_ws() {
cat > /var/www/html/ss-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
      Format Shadowsocks WS
-----------------------------------------
{ 
 "dns": {
    "servers": [
      "8.8.8.8",
      "8.8.4.4"
    ]
  },
 "inbounds": [
   {
      "port": 10808,
      "protocol": "socks",
      "settings": {
        "auth": "noauth",
        "udp": true,
        "userLevel": 8
      },
      "sniffing": {
        "destOverride": [
          "http",
          "tls"
        ],
        "enabled": true
      },
      "tag": "socks"
    },
    {
      "port": 10809,
      "protocol": "http",
      "settings": {
        "userLevel": 8
      },
      "tag": "http"
    }
  ],
  "log": {
    "loglevel": "none"
  },
  "outbounds": [
    {
      "mux": {
        "enabled": true
      },
      "protocol": "shadowsocks",
      "settings": {
        "servers": [
          {
            "address": "$domain",
            "level": 8,
            "method": "$cipher",
            "password": "$uuid",
            "port": $tls
          }
        ]
      },
      "streamSettings": {
        "network": "ws",
        "security": "tls",
        "tlsSettings": {
          "allowInsecure": true,
          "serverName": "isi_bug_disini"
        },
        "wsSettings": {
          "headers": {
            "Host": "$domain"
          },
          "path": "/shadowsocks"
        }
      },
      "tag": "proxy"
    },
    {
      "protocol": "freedom",
      "settings": {},
      "tag": "direct"
    },
    {
      "protocol": "blackhole",
      "settings": {
        "response": {
          "type": "http"
        }
      },
      "tag": "block"
    }
  ],
  "policy": {
    "levels": {
      "8": {
        "connIdle": 300,
        "downlinkOnly": 1,
        "handshake": 4,
        "uplinkOnly": 1
      }
    },
    "system": {
      "statsOutboundUplink": true,
      "statsOutboundDownlink": true
    }
  },
  "routing": {
    "domainStrategy": "Asls",
"rules": []
  },
  "stats": {}
}
END
}

function format_grpc() {
cat > /var/www/html/ss-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
      Format Shadowsocks gRPC
-----------------------------------------

{
    "dns": {
    "servers": [
      "8.8.8.8",
      "8.8.4.4"
    ]
  },
 "inbounds": [
   {
      "port": 10808,
      "protocol": "socks",
      "settings": {
        "auth": "noauth",
        "udp": true,
        "userLevel": 8
      },
      "sniffing": {
        "destOverride": [
          "http",
          "tls"
        ],
        "enabled": true
      },
      "tag": "socks"
    },
    {
      "port": 10809,
      "protocol": "http",
      "settings": {
        "userLevel": 8
      },
      "tag": "http"
    }
  ],
  "log": {
    "loglevel": "none"
  },
  "outbounds": [
    {
      "mux": {
        "enabled": true
      },
      "protocol": "shadowsocks",
      "settings": {
        "servers": [
          {
            "address": "$domain",
            "level": 8,
            "method": "$cipher",
            "password": "$uuid",
            "port": $tls
          }
        ]
      },
      "streamSettings": {
        "grpcSettings": {
          "multiMode": true,
          "serviceName": "shadowsocks"
        },
        "network": "grpc",
        "security": "tls",
        "tlsSettings": {
          "allowInsecure": true,
          "serverName": "isi_bug_disini"
        }
      },
      "tag": "proxy"
    },
    {
      "protocol": "freedom",
      "settings": {},
      "tag": "direct"
    },
    {
      "protocol": "blackhole",
      "settings": {
        "response": {
          "type": "http"
        }
      },
      "tag": "block"
    }
  ],
  "policy": {
    "levels": {
      "8": {
        "connIdle": 300,
        "downlinkOnly": 1,
        "handshake": 4,
        "uplinkOnly": 1
      }
    },
    "system": {
      "statsOutboundUplink": true,
      "statsOutboundDownlink": true
    }
  },
  "routing": {
    "domainStrategy": "Asls",
"rules": []
  },
  "stats": {}
}
END
}

 if [[ ${1} == "all" ]]; then
   style_all
 fi
 if [[ ${1} == "ws" ]]; then
   style_ws
 fi
 if [[ ${1} == "grpc" ]]; then
   style_grpc
 fi

 if [[ ${1} == "format_all" ]]; then
   format_all
 fi
 if [[ ${1} == "format_ws" ]]; then
   format_ws
 fi
 if [[ ${1} == "format_grpc" ]]; then
   format_grpc
 fi