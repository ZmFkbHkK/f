#!/bin/bash

function style_all() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}             TROJAN ACCOUNT              ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Username      : ${user}"
echo -e " User Quota    : ${Quota} GB"
echo -e " Limit IP      : ${iplimit} Device"
echo -e " Host/IP       : ${domain}"
echo -e " ISP           : ${ISP}"
echo -e " Country       : ${CITY}"
echo -e " Key           : ${uuid}"
echo -e " Port TLS      : $tls"
echo -e " Port none TLS : $ntls"
echo -e " Network       : ws - grpc"
echo -e " Path          : /trojan"
echo -e " ServiceName   : trojan-grpc"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link TLS      : ${trojanlink1}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link none TLS : ${trojanlink2}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link GRPC     : ${trojanlink3}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Format OpenClash : https://${domain}:89/trojan-$user.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e ""
}

function style_ws() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}             TROJAN ACCOUNT               ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Username      : ${user}"
echo -e " User Quota    : ${Quota} GB"
echo -e " Limit IP      : ${iplimit} Device"
echo -e " Host/IP       : ${domain}"
echo -e " ISP           : ${ISP}"
echo -e " Country       : ${CITY}"
echo -e " Key           : ${uuid}"
echo -e " Port TLS      : $tls"
echo -e " Port none TLS : $ntls"
echo -e " Network       : ws"
echo -e " Path          : /trojan"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link TLS      : ${trojanlink1}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link none TLS : ${trojanlink2}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Format OpenClash : https://${domain}:89/trojan-$user.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e ""
}

function style_grpc() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}             TROJAN ACCOUNT               ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Username      : ${user}"
echo -e " User Quota    : ${Quota} GB"
echo -e " Limit IP      : ${iplimit} Device"
echo -e " Host/IP       : ${domain}"
echo -e " ISP           : ${ISP}"
echo -e " Country       : ${CITY}"
echo -e " Key           : ${uuid}"
echo -e " Port TLS      : $tls"
echo -e " Port none TLS : $ntls"
echo -e " Network       : grpc"
echo -e " ServiceName   : trojan-grpc"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link GRPC     : ${trojanlink3}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Format OpenClash : https://${domain}:89/trojan-$user.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e ""
}

function format_all() {
cat >/var/www/html/trojan-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
        Format Trojan WS TLS
-----------------------------------------

- name: Trojan-$user-TLS
  server: ${domain}
  port: $tls
  type: trojan
  password: ${uuid}
  network: ws
  sni: ${domain}
  skip-cert-verify: true
  udp: true
  ws-opts:
    path: /trojan
    headers:
        Host: ${domain}

-----------------------------------------
        Format Trojan none TLS
-----------------------------------------
- name: Trojan-$user-WS TLS
  server: yourbug.com
  port: $ntls
  type: trojan
  password: ${uuid}
  network: ws
  sni: ${domain}
  skip-cert-verify: true
  udp: false
  ws-opts:
    path: /trojan
    headers:
        Host: ${domain}

-----------------------------------------
        Format Trojan gRPC
-----------------------------------------

- name: Trojan-$user-gRPC
  type: trojan
  server: ${domain}
  port: $tls
  password: ${uuid}
  udp: true
  sni: ${domain}
  skip-cert-verify: true
  network: grpc
  grpc-opts:
    grpc-service-name: trojan-grpc

-----------------------------------------
Link Trojan Account
-----------------------------------------
Link WS TLS :
${trojanlink}
-----------------------------------------
Link none TLS :
${trojanlink2}
-----------------------------------------
Link GRPC : 
${trojanlink1}
-----------------------------------------

END
}

function format_ws() {
cat >/var/www/html/trojan-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
        Format Trojan WS TLS
-----------------------------------------

- name: Trojan-$user-TLS
  server: ${domain}
  port: $tls
  type: trojan
  password: ${uuid}
  network: ws
  sni: ${domain}
  skip-cert-verify: true
  udp: true
  ws-opts:
    path: /trojan
    headers:
        Host: ${domain}

-----------------------------------------
        Format Trojan none TLS
-----------------------------------------
- name: Trojan-$user-WS TLS
  server: yourbug.com
  port: $ntls
  type: trojan
  password: ${uuid}
  network: ws
  sni: ${domain}
  skip-cert-verify: true
  udp: false
  ws-opts:
    path: /trojan
    headers:
        Host: ${domain}

-----------------------------------------
Link Trojan Account
-----------------------------------------
Link WS TLS :
${trojanlink}
-----------------------------------------
Link none TLS :
${trojanlink2}
-----------------------------------------
END
}

function format_grpc() {
cat >/var/www/html/trojan-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
        Format Trojan gRPC
-----------------------------------------

- name: Trojan-$user-gRPC
  type: trojan
  server: ${domain}
  port: $tls
  password: ${uuid}
  udp: true
  sni: ${domain}
  skip-cert-verify: true
  network: grpc
  grpc-opts:
    grpc-service-name: trojan-grpc

-----------------------------------------
Link Trojan Account
-----------------------------------------
Link GRPC : 
${trojanlink1}
-----------------------------------------
END
}

 if [[ ${1} == "all" ]]; then
   style_all
 fi
 if [[ ${1} == "ws" ]]; then
   style_ws
 fi
 if [[ ${1} == "grpc" ]]; then
   style_grpc
 fi

 if [[ ${1} == "format_all" ]]; then
   format_all
 fi
 if [[ ${1} == "format_ws" ]]; then
   format_ws
 fi
 if [[ ${1} == "format_grpc" ]]; then
   format_grpc
 fi