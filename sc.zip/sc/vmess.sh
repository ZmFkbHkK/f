#!/bin/bash

function style_all() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}             VMESS ACCOUNT               ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Username      : ${user}"
echo -e " User Quota    : ${Quota} GB"
echo -e " Limit IP      : ${iplimit} Device"
echo -e " Host/IP       : ${domain}"
echo -e " ISP           : ${ISP}"
echo -e " Country       : ${CITY}"
echo -e " id            : ${uuid}"
echo -e " Port TLS      : $tls"
echo -e " Port none TLS : $ntls"
echo -e " alterId       : 0"
echo -e " Security      : auto"
echo -e " Network       : ws - grpc"
echo -e " Path          : /vmess"
echo -e " ServiceName   : vmess-grpc"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link TLS      : ${vmesslink1}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link none TLS : ${vmesslink2}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link GRPC     : ${vmesslink3}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Format OpenClash : https://${domain}:89/vmess-$user.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e ""
}

function style_ws() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}             VMESS ACCOUNT               ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Username      : ${user}"
echo -e " User Quota    : ${Quota} GB"
echo -e " Limit IP      : ${iplimit} Device"
echo -e " Host/IP       : ${domain}"
echo -e " ISP           : ${ISP}"
echo -e " Country       : ${CITY}"
echo -e " id            : ${uuid}"
echo -e " Port TLS      : $tls"
echo -e " Port none TLS : $ntls"
echo -e " alterId       : 0"
echo -e " Security      : auto"
echo -e " Network       : ws"
echo -e " Path          : /vmess"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link TLS      : ${vmesslink1}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link none TLS : ${vmesslink2}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Format OpenClash : https://${domain}:89/vmess-$user.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e ""
}

function style_grpc() {
clear
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e "${ungu}             VMESS ACCOUNT               ${NC}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Username      : ${user}"
echo -e " User Quota    : ${Quota} GB"
echo -e " Limit IP      : ${iplimit} Device"
echo -e " Host/IP       : ${domain}"
echo -e " ISP           : ${ISP}"
echo -e " Country       : ${CITY}"
echo -e " id            : ${uuid}"
echo -e " Port TLS      : $tls"
echo -e " Port none TLS : $ntls"
echo -e " alterId       : 0"
echo -e " Security      : auto"
echo -e " Network       : grpc"
echo -e " ServiceName   : vmess-grpc"
echo -e " Port TLS      : $tls"
echo -e " Port none TLS : $ntls"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Link GRPC     : ${vmesslink3}"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Format OpenClash : https://${domain}:89/vmess-$user.txt"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e " Created On    : $hariini"
echo -e " Expired On    : $exp"
echo -e "${blue}————————————————————————————————————————${NC}"
echo -e ""
}

function format_all() {
cat >/var/www/html/vmess-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
        Format Vmess WS TLS
-----------------------------------------
- name: Vmess-$user-WS TLS
  type: vmess
  server: ${domain}
  port: $tls
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: ${domain}

-----------------------------------------
        Format Vmess none TLS
-----------------------------------------

- name: Vmess-$user-WS Non TLS
  type: vmess
  server: ${domain}
  port: $ntls
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: false
  skip-cert-verify: false
  servername: none
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: ${domain}

-----------------------------------------
        Format Vmess gRPC
-----------------------------------------

- name: Vmess-$user-gRPC (SNI)
  server: ${domain}
  port: $tls
  type: vmess
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  network: grpc
  tls: true
  servername: ${domain}
  skip-cert-verify: true
  grpc-opts:
    grpc-service-name: vmess-grpc

-----------------------------------------
        Link Vmess Account
-----------------------------------------
Link WS TLS      : 
${vmesslink1}
-----------------------------------------
Link none TLS    : 
${vmesslink2}
-----------------------------------------
Link GRPC        : 
${vmesslink3}
-----------------------------------------

END
}

function format_ws() {
cat >/var/www/html/vmess-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
        Format Vmess WS TLS
-----------------------------------------
- name: Vmess-$user-WS TLS
  type: vmess
  server: ${domain}
  port: $tls
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: ${domain}

-----------------------------------------
        Format Vmess none TLS
-----------------------------------------

- name: Vmess-$user-WS Non TLS
  type: vmess
  server: ${domain}
  port: $ntls
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: false
  skip-cert-verify: false
  servername: none
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: ${domain}

-----------------------------------------
        Link Vmess Account
-----------------------------------------
Link WS TLS      : 
${vmesslink1}
-----------------------------------------
Link none TLS    : 
${vmesslink2}
-----------------------------------------
END
}

function format_grpc() {
cat >/var/www/html/vmess-$user.txt <<-END
-----------------------------------------
        XDTunnel PROJECT
-----------------------------------------
    Telegram : https://t.me/xdxl_store
-----------------------------------------
        Format Vmess gRPC
-----------------------------------------

- name: Vmess-$user-gRPC (SNI)
  server: ${domain}
  port: $tls
  type: vmess
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  network: grpc
  tls: true
  servername: ${domain}
  skip-cert-verify: true
  grpc-opts:
    grpc-service-name: vmess-grpc

-----------------------------------------
        Link Vmess Account
-----------------------------------------
Link GRPC        : 
${vmesslink3}
-----------------------------------------
END
}

 if [[ ${1} == "all" ]]; then
   style_all
 fi
 if [[ ${1} == "ws" ]]; then
   style_ws
 fi
 if [[ ${1} == "grpc" ]]; then
   style_grpc
 fi

 if [[ ${1} == "format_all" ]]; then
   format_all
 fi
 if [[ ${1} == "format_ws" ]]; then
   format_ws
 fi
 if [[ ${1} == "format_grpc" ]]; then
   format_grpc
 fi